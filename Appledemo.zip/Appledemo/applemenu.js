
    $(document).ready(function(){
        $('#searchbtn').click(function(){
           var text=$('#search').text();
           
           $('.main').find('a').each(function(){
               if(text==$(this).text()){
                
                console.log(text);
               }
            })
        })
    })
